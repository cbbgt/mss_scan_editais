
import re


def reduce_html(html: str):
    return re.sub(r">\s+<", "><", html).strip()
